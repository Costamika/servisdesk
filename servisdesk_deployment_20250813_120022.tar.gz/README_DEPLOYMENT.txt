=== ServisDesk - Система управления заявками ===

Этот архив содержит полную систему ServisDesk для развертывания на сервере.

=== Содержимое архива ===

📁 Основные компоненты:
- servisdesk/ - Основное приложение Django
- tickets/ - Модуль управления заявками
- users/ - Модуль управления пользователями
- templates/ - HTML шаблоны
- static/ - Статические файлы (CSS, JS)

📋 Конфигурация:
- config_ip_system.py - Настройки IP и порта
- gunicorn.conf.py - Конфигурация Gunicorn
- nginx.conf - Конфигурация Nginx
- docker-compose.yml - Docker Compose
- Dockerfile - Docker образ

📚 Документация:
- README.md - Основная документация
- README_DEPLOYMENT.md - Руководство по развертыванию
- QUICK_DEPLOY.md - Быстрое развертывание
- DEPLOYMENT.md - Подробное развертывание

🚀 Скрипты развертывания:
- deploy.sh - Основной скрипт развертывания
- deploy_server.sh - Развертывание на сервере
- deploy_local.sh - Локальное развертывание
- start_server.sh - Запуск сервера
- manage_service.sh - Управление службой

=== Быстрый старт ===

1. Распакуйте архив:
   tar -xzf servisdesk_deployment_*.tar.gz

2. Перейдите в директорию:
   cd deployment_temp

3. Запустите развертывание:
   ./deploy.sh

=== Подробная документация ===

См. файлы:
- README_DEPLOYMENT.md - Подробное руководство
- QUICK_DEPLOY.md - Быстрое развертывание
- DEPLOYMENT.md - Полная документация

=== Версия ===

Создан: $(date)
Версия: 1.0.0
